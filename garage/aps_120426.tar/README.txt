This document will provide a guided tour of the code provided in this package. 

Section I will point out the requirements and dependencies of the code.

Section II will give a qualitative description of the source code files. 

Section III will describe aps_interface.cpp the user interface code for the 
APS alogrithm.

Section IV will provide a description of the subroutines in
likelihoodinterface.cpp, which is where most of the work implementing the
APS algorithm is done.  

Section V will describe the output produced by the code.

Readers only interested in how to interface their particular data and likelihood
function with this code should read Section III and the discussion of the
likelihood::call_likelihood(double *v) subroutine in Section IV.

You are welcome to use, modify, and distribute this code as you see fit.  If you
end up using it, please cite

B. Bryan, J. Schneider, C. J. Miller, C. Genovese, and L. Wasserman, Apj 665:225
(2007)

and

S.F. Daniel, A. Connolly, and J. Schneider [arXiv:1205.2708] (2012)

Throughout this document ``the text'' will refer to Daniel, Connolly, and
Schneider (2012).

////////////////////////

I. Required software

In order to run this software, you must have a version of the Fortran linear
algebra libraries BLAS (http://www.netlib.org/blas/faq.html) and LAPACK
(http://www.netlib.org/lapack/).

Two versions of the code are presented: one (current configuration) uses a 
cartoon likelihood function in two-dimensional parameter space with two islands 
of high likelihood; the other uses the WMAP 7 year likelihood function in 6 
dimensional cosmological parameter space.  If you are interested in running the 
CMB likelihood function, change the Makefile to uncomment the CMB compile 
command for likelihoodinterface.o and comment out the cartoon version.
Make a similar change to the subroutine call_likelihood(double*) in
likelihoodinterface.cpp (i.e. uncomment the WMAP 7 likelihood function and
comment out the cartoon likelihood).

The CMB version of the code interfaces with the January 2011 release of 
CAMB (http://camb.info/readme.html) and the WMAP 7 likeihood code
(http://lambda.gsfc.nasa.gov/product/map/current/likelihood_info.cfm) to
calculate constraints on cosmological parameters.  In order to run this code,
you will also need to download and compile a cfitsio library
(http://heasarc.nasa.gov/fitsio/fitsio.html).  This is actually a requirement of
WMAP7 and CAMB, not APS.

To compile the code, edit the Makefile so that LAPACK, BLAS, CAMB, CFITSIO,
WMAP, and WMAPLIBS point to the appropriate directories.  

Also alter gg and ff so that they refer to your native C++ and Fortran 
compilers.  

FORTRAN should refer to whatever libraries are necessary to make your C++
compiler talk to your Fortran compiler.  This is necessary if LAPACK and BLAS
are compiled in Fortran.  In our case, we compiled LAPACK and BLAS using the
gfotran compiler, so our FORTRAN flag had to be -lgfortran.

You can uncomment the openmp flags if you want to parallelize the code using
openmp.

To compile the CMB code, simply type "make aps".  This will compile an 
executable ./aps which can be called with a parameter input file (for an
example, see the included files params.sav and params_CMB.sav*) to run the APS
algorithm on the likelihood code and data that has been hard-coded into
likelihoodinterface.cpp (see Sections III and IV below).

*params.sav is written to run on the cartoon likelihood function. 
params_CMB.sav is written for the WMAP 7 likelihood function.

Running this code will produce two output files.  One, whose name is specified
in the parameter file (in this case, test_out.sav) will record all of the points
sampled by the algorithm, along with several statistics which will allow you to
check on the accuracy of the Gaussian process.  Another file, timingfile.sav 
will log the progress of the code, including statistics indicating how much 
time is being spent on the likelihood function and how much time is being 
spent on the Gaussian process (so that the user can set parameters such as the 
number of Gaussian process candidates and nearest neighbors to optimize 
resource usage).

After the algorithm has run for the specified number of iterations, it will
write the minimum and maximum acceptable (chi-squared <= chi_squared_lim) values
found for each parameter to stdout.

/////////////////////////

II. Overview of provided source code

goto_tools.cpp

This is a file containing some general purpose routines (most of them taken 
from Numerical Recipes).  Most notably, there is a polynomial interpolater and
wrapper as well as a merge sort routine.  goto_tools.h encodes the uniform
random number class Ran, also taken from Numerical Recipes.

eigen_wrapper.cpp

This contains a matrix inversion routine based on functions in the LAPACK
library.  It is used to invert the covariogram matrices in the Gaussian process.

kd.cpp

This contains code implementing a kd-tree.  This tree is used to store the set
of points in parameter space sampled by the code.  They are organized to
facilitate efficient nearest-neighbor searches in the Gaussian process.

likelihoodinterface.cpp

This file contains all of the subroutines unique to the APS algorithm. 
They exist within a class of object called 'likelihood'.  Section IV will
detail the use of each routine.

aps_interface.cpp

This is the user interface that ultimately initializes and calls likelihood.cpp.
It will read in the parameter file (e.g. params.sav) and use the information
therein to set the customizable parameters controlling how APS is run.

camb_wrapper_wmap.F90

This contains the code which calls CAMB to convert cosmological parameters into
a CMB anisotropy spectrum.

wmap_wrapper.F90

This contains the code that calls the WMAP 7 likelihood function on the output
from camb_wrapper_wmap.F90

////////////////////////

III. aps_interface.cpp

After typing

    make aps
    
you will have an executable that can be run in the form

    ./aps params.sav

params.sav is a list of keywords and parameter values.  There should be a space
separating the keyword and the corresponding value.  The keyword/parameter pairs
can appear in any order except that 'dim' (setting the number of parameters in
your parameter space) must come first.  The acceptable parameters are

#dim N -- set the dimensionality of your parameter space to N (again,
this must be the first line in params.sav
		
#param i name min max -- set the name of the ith parameter to 'name'; set the
minimum and maximum allowed values of the ith parameter to min and max.  Note:
parameters are zero-indexed, so i goes from 0 to N-1 for N-dimensional space

#Ns S -- start APS by randomly sampling S points uniformly

#Nk K -- after randomly sampling the points above, sample another K points
uniformly and use them to set the Kriging parameter

#Ng G -- use G nearest neighbors in the Gaussian process

#Nc D -- use D random candidates at each iteration of the Gaussian process

#end E -- end APS after it has sampled E points

#chitarget C -- set the target value of chi square for your desired confidence
limit to C

#chimin M -- set the expected minimum value of chi squared (used for the
gradient descent in the lingering algorithm) to M

#linger J -- turn on the lingering algorithm.  Each time lingering is
invoked, linger for J iterations

#outputfile filename.txt -- output the points sampled to filename.txt.  Note, if
filename.txt already exists, the code will just append its output to the end of
the file.

#resumefile oldfilename.txt -- read in oldfilename.txt (which is an old iteration of
the output above) and resume running APS (writing the output to the file
specified by the output keyword)

#write_every W -- write the output file every W sampled points.  This also
governs how often the code assesses the appropriateness of its Kriging
parameter.  W is set to 100 by default.

#guess (list of N numbers) -- if you are starting a new iteration of APS, you
can use guesses to make sure that the initial 'random' sample of S points
contains certain points of interest.  This could be useful for cases where you
know where the maximum likelihood point is in parameter space.  You do not need
to supply any guesses.  It is purely optional.


///////////////////////

IV. likelihoodinterface.cpp

In this section, we will outline the behavior of the member subroutines of the
class likelihood, which do all of the work associated with the APS
algorithm.  We will start out of order with

double likelihood::call_likelihood(double *v)

This is the only subroutine that user absolutely must change in order to
interface with her particular data and likelihood function.  The subroutine
accepts a point in parameter space v[] and uses that point (and calls to the
user's own external functions) to calculate a value of chi-squared.  The
subroutine returns chi-squared. As presented, it uses a cartoon likelihood 
function in two-dimensional parameter space.  There is also commented code 
which uses CAMB to constrain cosmological parameters against the 7 year 
release WMAP CMB data.

likelihood::likelihood(int nn, double *mns, double *mxs)

This class constructor only alots space in certain arrays so that the 
algorithm can do its work.  nn is the number of dimensions in your parameter 
space.  mns[] and mxs[] are the upper and lower bounds allowed
for each of your parameters.  This routine will set default values of kk (the
number of nearest neighbors used in the Gaussian process), nsamples 
(the number of candidates called for the Guassian process), and npts (the 
number of random points with which to start your algorithm).  You can assign 
different values for these parameters (as happens in aps_interface.cpp) 
before calling likelihood::initialize() with no ill effect.

The arrays allotted by this algorithm are as follows:

CLmin[] and CLmax[] -- once you start finding points that are within your
confidence limit (i.e. chi-squared <= target), these will store the minimum and
maximum value of each parameter in parameter space that satisfies your
confidence limit.

mins[] and maxs[] -- these will copy mns[] and mxs[] for use inside the
algorithm.


kptr[] -- points sampled by the algorithm are stored in kd trees to facilitate
rapid nearest neighbor searches.  In order to parallelize the Gaussian process 
portion of the code, each separate openmp thread must have its own kd tree to 
prevent simultaneous nearest neighbor searches from interfering with each other.
Note: each kd tree object has an associated integer 'diagnostic'.  The integer
is set to unity if the tree is self-consistent (all of the nodes are arranged
and related to each other the way they should be).  It is set to zero if they
are not.  If you ever doubt that the kd tree code is working properly, call
kptr[i]->check_tree(-1).  This will inspect the tree and then set 'diagnostic' 
to the appropriate value (the argument -1 tells the routine to check the entire
tree).  The subroutine likelihood::write_pts(char*) does this automatically. 
Depending on how often you are calling write_pts(), that may slow your code
down, so you can elect to comment that line out without ill-effect.

void likelihood::initialize(double **guesses, int nguess)

This routine will sample the initial random set of points and arrange them into
the kd trees to prepare for Kriging.  It will add the nguess points stored in
guesses[][] to that initial sample.

void likelihood::resume(char *inname)

If a run of the code was interrupted for some reason, you can call this routine
with inname referring to the name of the old output file.  This will read in
the data stored in that file and then resume the code where you left off.  Note:
reading in the data does not automatically set parameters such as kk, nsamples
or lingering, so aps_interface still sets those ``by hand''.

void likelihood::add_pt(double *v, double *dd, double fin, double sin, \
double chitrue)

After the Gaussian process has chosen a point to evaluate (this is done in
likelihood::sample_pts(int)), and likelihood::call_likelihood(double*) has
evaluated chi-squared for that point, this routine will add it to the kd trees 
storing the data.  It will also update the array storing the values of chi-
squared and other run-time data. The arguments are

v[] -- the point in parameter space to be added
dd[] -- the list of distances to the Gaussian process nearest neighbors
fin -- the value of chi-squared predicted by the Gaussian process (mu in text)
sin -- the value of sigma yielded by the Gaussina process (uncertainty on mu)
chitrue -- the value of chi-squared yielded by likelihood::call_likelihood(v)

In the event that there is not enough memory in the data arrays to accommodate
the new point (i.e. npts==room), this routine will also alot new memory for
those arrays with appropriate calls of delete [] and new [].

The data arrays that are updated by this routine are as follows

kpa[] -- this stores the value of the Kriging parameter at the time
likelihood::add_pt() was called

fpredicted[] -- this stores the value of chi-squared predicted by Kriging for
each point when it was sampled (\mu in the text)

sigma[] -- this stores the Gaussian process uncertainty associated with
fpredicted[] for each point.  Note: it actually stores 
\sigma/sqrt(Kriging parameter) so that the Kriging parameter can be
heuristically reset in the future (this will hopefully make more sense after we
have discussed the likelihood::set_kp() routine)

chisq[] -- stores the values of chi-squared associated with each pooint

ddmin[], ddmax[], ddavg[] -- store the minimum, maximum, and average distances
to the kk nearest neighbors used for each point during the Gaussian process

suboptime[] -- this stores the number of points chosen suboptimally (i.e.
because of large \sigma rather than proximity to chi-squared==target) at the
point when likelihood::add_pt() was called.

suboptct[] -- this stores the number of points sampled while the code was not
lingering, so that suboptime[]/suboptct[] gives a fraction of points that have
been chosen suboptimally so far.

If, after this algorithm has been called, the number of sampled points is an
integer multiple of writevery (W in section III), the algorithm will call 
write_pts() and write  the output.  It will also assess whether or not the 
Kriging parameter should be adjusted so that more or fewer points are chosen 
suboptimally.  

void likelihood::sample_pts(int delswit)

This routine will generate kk random points in parameter space, use a Gaussian
process to predict the associated values of chi-squared, choose (using the 
statistical test described in equation (2) of the text) one to evaluate, 
actually evaluate that point with likelihood::call_likelihood(v) and call l
ikelihood::add_pt() to add that point to the kd trees and other data arrays.  
The argument 'delswit' is just a switch.  If delswit>0, the routine behaves as 
just described.  If delswith<0, the routine will delete several static arrays 
that are necessary for its functioning and return without sampling anything.

This is also the routine where the code governing the linger option exists.

This routine also keeps track of how many points are chosen subopitmally (for
large values of Gaussian process \sigma, rather than proximity to 
chi-squared==target) and keeps track of the average time (both wall time and 
cpu ticks) spent on Kriging and the likelihood function.

void likelihood::write_pts()

This algorithm will write the data recorded so far to the file whose name is
specified in the parameter file (and stored in char masteroutname[]).  
It will also write the data related to timing the code to timingfile.sav.

There is a for loop at the beginning of this algorithm which checks whether or
not the kd trees are still properly constructed.  This can be excised for
efficiency if the user anticipates calling likelihood::write_pts() frequently.

double likelihood::covariogram(double *v1, double *v2, int coords)

Given two points in parameter space v1[] and v2[], this algorithm returns the
covariogram between them.  It is used in the Gaussian process.

void likelihood::predict(double **old, double *ffn, double *q, double *dd, \
int pts, int coords, double *mu, double *sig, int delswit)

This routine (also called in likelihood::sample_pts()) takes a test point q[], a
set of known points old[][] and uses a Gaussian process to predict chi-squared 
at q[].  The predicted value of chi-squared is stored in *mu.  The uncertainty 
on that prediction is stored in *sig.  ffn[] stores the chi-squared values 
associated with the points in old[][].  dd[] stores the distances in parameter 
space between q[] and the points in old[][] (this is given for free by the 
nearest neighbor search algorithm called in likelihood::sample_pts()).  
'delswit' behaves the same as in likelihood::sample_pts() i.e. if delswit>0 
the routine does what it is supposed to do; if delswit<0, the routine deletes 
several static arrays and returns.

double likelihood::test_kp(int pts, char *name)

This subroutine provides one means of testing the code's current choice of
Kriging parameter.  When called, it will generate pts random points in parameter
space, use a Gaussian process to predict the corresponding values of 
chi-squared, and then actually call the likelihood function to find their true 
values of chi-squared. The routine returns the fraction of these random points 
for which the true value of chi-squared was within 1-\sigma of the 
Gaussian-process-predicted value (where \sigma is the Gaussian process 
uncertainty as in the text).  If this value is too small, you can
increase the Kriging parameter.  If the value is too large, you can decrease 
the Kriging parameter.  

name[] specifies a file in which the results of this test (the number of points
generated, the number and fraction of points trapped, the number of data points 
sampled so far, the value of the Kriging parameter, and the number of points 
chosen suboptimally thus far) is stored.  Note: this routine actually uses the
parameter rkp in place of kriging_parameter, just in case it is called while the
code is lingering (and kriging_parameter is set to a very small number).

Because the routine actually spends the time to call the likelihood function, 
it calls likelihood::add_pt() to add those points to the list of known points.
``Waste not, want not.''

void likelihood::set_kp(int ignore)

This routine provides a way to heuristically set the Kriging parameter after the
algorithm has run for a while.  When called, this routine will consider all of
the data points currently stored, ignoring the first 'ignore' points, and then
set the Kriging parameter to whatever value is necessary such that 68% of those
points satisfy the condition 

|chisquared-mu|<=sigma*sqrt(Kriging parameter)

where mu is the value predicted by the Gaussian process and sigma is the 
uncertainty on that value (in the case that the Kriging parameter = 1).  This 
is why the array  sigma[] ignores the present value of the Kriging parameter 
(see the discussion of the arrays updated by likelihood::add_pt())

///////////////////////

V. Output produced by this software

This code will produce two main output files. 

filename.txt -- the file specified in the params.sav file

This is the principal file produced by likelihood::write_pts().
Each line of this file corresponds to a different point in parameter space
sampled by the code.  The first N columns are the values of the N-dimensions of
parameter space (they will be labeled with the names stored in the character
array likelihood.paramnames[][]).  The subsequent columns are as follows:

'chisq' -- chi-squared for the point (the actual chi-squared)

'predicted' -- the value of chi-squared predicted by Kriging for that point
(\mu in the text)

'sig' -- the uncertainty on 'predicted' (\sigma in the text).  Note: this is
the value stored in the sigma[] array multiplied by sqrt(Kriging parameter at
the time the point was sampled). See, for example, the discussion about the 
arrays updated by likelihood::add_pt() in Section IV.  Points sampled under
lingering will have sig=0.

'diffpct' -- the difference (as a ratio) between 'chisq' and 'predicted' i.e.
|(chisq - predicted)/chisq|

'ddmin', 'ddmax', 'ddavg' -- the minimum, maximum, and average distance from
the point to its kk nearest neighbors when the Gaussian process was used on the 
point.  Though you may not see a correlation between these numbers and 
'diffpct', you should see an obvious correlation wth 'sig' (if the 'dds' are 
small, 'sig' should be small and vice-versa)

'goodpct' -- the fraction of points sampled that are within the desired
confidence limit, i.e. that satisfy chi-squared <= target

'triedpct' and 'wayoff' -- the fraction of points for which 'predicted' was
within 10% of target or differed from target by more than 90%.  These are
provided as another gauge of the Kriging parameter.  If the Kriging parameter
is too small, 'triedpct' will near 1.0 as the code focuses only on finding
points that are near chi-squared == target.  If the Kriging parameter is too
large, way off will be near 1.0 as the opposite behavior will be emphasized. 
Note: points sampled during lingering do not count towards these ratios.

'suboptimal' -- the number of points sampled suboptimally (because of large
\sigma rather than proximity to chi-squared == target)

'suboptpct' -- the fraction of points (which are not sampled under lingering)
that are sampled suboptimally

'trappedpct' -- the fraction of points for which

     |chisquared-predicted|<=sqrt(Kriging parameter)*sig

Note: this statistic assesses each point against the Kriging parameter at the
time that point was sampled.  It does not go back and reevaluate whether old 
points would have been trapped using new values of the Kriging parameter.

'kp' -- the Kriging parameter at the time the point was evaluated.

Note: if you alter likelihood::write_pts() it is important that you do not
change any of the current labels and that 'kp' is always the last column. 
likelihood::resume() requires these conditions in order to properly parse the
data.

timingfile.sav

This file contains information about each run as an average.  

The first column is the name of the root_out.sav file to which the line is 
referring.  

The second column is the total number of points sampled.  

The third column ('ling') is the number of iterations spent lignering

The fourth column ('gd') is the number of points found within your desired 
confidence limit.  

'avgkrigtimewall' refers to the average number of seconds (since the last time 
likelihood::write_pts() was called) spent on sampling and Gaussian process
candidate points.

'avgaddtimewall' refers to the average number of seconds spent calling the 
likelihood function and adding points to the data arrays.  

'ns' refers to the number of random samples chosen for the Gaussian process.

'kk' is the number of nearest neighbors chosen for the Gaussian process.

'avgkrigtimecpu' and 'avgaddtimecpu' are the same as 'avgkrigtimewall' and
'avgaddtimewall' except that they refere to the number of elapsed cpu clock 
ticks (the output of the C++ subtoutine clock() )

'suboptpct' refers to the percentage of points chosen suboptimally. 

'ct' is the number of points chosen without lingering (i.e. the denominator of 
'suboptpct').

'kp' lists the current value of the Kriging parameter. 

The 'kd#' columns display the value of 'diagnostic' for the kd trees (they 
should be unity if everything is well-behaved). 

'target' is the chi-squared value you are looking for.

test_kp_file.txt -- the char* argument to likelihood::test_kp(int,char*)

This will record statistics whenever you use likelihood::test_kp() to evaluate
the current choice of Kriging parameter.  It will record: the number of random 
points used to evaluate the Kriging parameter; the number and percentage of 
those points for which the true chi-squared value was within 1-\sigma of the 
Kriging prediction, the total number of data points stored in the data arrays, 
the current value of the Kriging parameter, and the total number of points 
chosen suboptimally so far.

If errors are encountered in the Gaussian process, they are output to a file
named gp_error.sav
