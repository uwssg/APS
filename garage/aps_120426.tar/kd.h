//this is the 27 February 2012 rewrite

class kd_tree{
 private:
  int **tree;
  int masterparent;
  int room,roomstep;
  double tol;
  
  void confirm(int,int,int,int);
  void organize(int*,int,int,int,int);
  int find_node(double*);
  void neigh_check(double*,int,int*,double*,int,int);
  
 public:
  int dim,pts,diagnostic,xplr;

  double **data,*maxs,*mins;

  kd_tree(int,int,double**,int*,double*,double*);
  ~kd_tree();
 
 void check_tree(int);
 double distance(double*,double*);

 void write_tree(char*);
 void add(double*);
 void nn_srch(double*,int,int*,double*);
};
