#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef OPENMP
#include <omp.h>
#else
#define omp_get_num_threads() 1
#define omp_get_thread_num() 0
#endif

#include <time.h>
#include "likelihoodinterface.h"
#include "eigen_wrapper.h"

int ipower(int arg, int ee){
  int ans,i;
  
  ans=1;
  for(i=0;i<ee;i++)ans=ans*arg;
  
  return ans;
}

likelihood::~likelihood(){
  int i;
  double **dd,*d;

  //Call subroutines with delswit=-1 so that they delete
  //pointers that were allocated on their initial call  
  predict(dd,d,d,d,nparams,i,d,d,-1);
  sample_pts(-1);
 
  delete [] fpredicted;
  for(i=0;i<threads;i++)delete kptr[i];
  delete kptr;
  delete dice;
  delete [] mins;
  delete [] maxs;
  delete [] chisq;
  delete [] sigma;
  delete [] ddmin;
  delete [] ddavg;
  delete [] ddmax;
  delete [] suboptime;
  delete [] suboptpct;
  delete [] CLmax;
  delete [] CLmin;  
  delete [] kpa;
}

likelihood::likelihood(){
 
 printf("WARNING called the likelihood default constructor\n");
  printf("you shouldn't do that...");
  printf("I'm going to freeze the program now\n");
  scanf("%lf",&junk);
}

likelihood::likelihood(int nn,double *mns,double *mxs){

 //This routine doesn't actually do much.
 //It just builds some of the necessary matrices
 //and assigns the values you want to some of the
 //class member variables.  The real action of
 //beginning to explore parameter space is in
 //likelihoodinterface.initiailize()

 //nn is the number of parameters
 
 //*mns and *mxs are the min and max values allowed in parameter space
 
 int i,j,k,l;
 double rn;
 
 printf("starting\n");
 
 roomstep=100000; //When the arrays storing all of the known points
 		//need to be expanded, this is the amount they are expanded by

 lingerswitch=0; //default is that lingering will not happen
 lingermax=50;

 writevery=100; //call write_pts() every 100 sampled points
 
 nprinted=0; //keep track of how many points have been written with
 		//write_pts() so that you do not write the same point
		//twice.
 maxerr=-1.0;

 precision=0.001;//how close to the confidence limit is close enough

 spentlingering=0;
 lastsubop=0;

 printf("in likelihood constructor\n");
 #pragma omp parallel
 threads=omp_get_num_threads();
 printf("threads is %d\n",threads);

 
 i=int(time(NULL));
 
 printf("\n\nran seed is %d\n\n",i);

 dice=new Ran(i);
 npts=10000; //Number of random starting point sampled.
 	//This is a public parameter, so you can
	//set it to a different value before calling
	//likelihood.initialize()
 
 kk=15; //Number of nearest neighbors in the Gaussian Process 
 	//(also can be reset)

 nsamples=1000; //Number of samples to consider when using the Gaussian process

 target=1280.0; //Default value of chi squared for which to look
 chimin=1197.0;

 nparams=nn;
 kpmin=0.00001; //Value that kriging parameter gets set to in case of lingering

 CLmin=new double[nparams];//These will store the current upper and lower 
 CLmax=new double[nparams];//confidence limit bounds on parameters
 
 for(i=0;i<nparams;i++){
   CLmin[i]=1.0e10;
   CLmax[i]=-1.0e10;
 }
 

 kriging_parameter=1.0;
 rkp=1.0;

 mins=new double[nparams];
 maxs=new double[nparams];

 for(i=0;i<nparams;i++){
  mins[i]=mns[i];
  maxs[i]=mxs[i];
 }
 
 kptr=new kd_tree*[threads];
 //In order to allow parallelization without threads 
 //interfering with each other,
 //each thread needs its own kdtree storing the known points for the Gaussian
 //process.
 
}

void likelihood::initialize(double **guesses, int nguess){

//This routine will actually generate the initial set of random samples,
//evaluate their chi squared values,
//and store them in the kdtrees for the Gaussian process

 int i,j,k,l,*inn;
 double rn,tp,cc;
 double **base;
 
 //These are all parameters related to the timing statistics
 //recorded in timingfile.sav
 krigct=0;
 addct=0;
 krigtimewall=0.0;
 addtimewall=0.0;
 krigtimecpu=0.0;
 addtimecpu=0.0;
 
 
 ngood=0;//Number of points found within the confidence limit
 
 startpts=npts;//Number of points you are starting with
 
 room=npts;//This will be the initial size of the arrays keeping track
 	//of things like chi squared for all sampled points.
	//This is what gets incremented by roomstep when necessary.
	//It is not equal to npts to cut down on the number of times
	//we have to call delete [] and new []
 
 suboptimal=0;//Number of points chosen because of large 
 	     //sigma rather than small |target-mu|
 
 suboptct=0;//Number of total points chosen not counting lingering.
 	//suboptimal/suboptct is the percentage of points chosen for 
	//large sigma
		    
 fpredicted=new double[npts]; //This stores the value of chi squared
 			//predicted for each evaluated point, so
			//you can check if the Gaussian Process/Kriging
			//code is working properly
			
 sigma=new double[npts]; //This is the sqrt(variance) of each point predicted
 			//by the Gaussian Process/Kriging code

 chisq=new double[npts];
 
 ddmin=new double[npts];//These store the min, max, and average distances
 ddavg=new double[npts];//between evaluated candidate points and their kk
 ddmax=new double[npts];//nearest neighbors.  This information allows us to
 			//verify that the Gaussian process gets more accurate 
			//as ddavg gets smaller
 
 suboptime=new int[npts]; //this allows us to keep track of the number of 
 			//points chosen suboptimally
 			//as a function of number of points chosen 
			//(i.e. a time series)
			
 suboptpct=new double[npts]; //same as above for percentage of 
 				//suboptimal points

 kpa=new double[npts]; //this will store kriging parameter as a 
 			//function of time


 printf("initializing likelihood object\n");
 
 
 //below is the code to select the random base of points to start with
 
 base=new double*[npts];
 for(i=0;i<npts;i++){
  base[i]=new double[nparams];
 }
 
 printf("declared base npts %d params %d\n",npts,nparams);
 
 //first read in the supplied guesses
 for(j=0;j<nguess;j++){
   for(i=0;i<nparams;i++)base[j][i]=guesses[j][i];
 }
  
 for(;j<npts;j++){
  for(i=0;i<nparams;i++){
   rn=dice->doub();
   base[j][i]=(maxs[i]-mins[i])*rn+mins[i];
  }
  
 }
 
 
 printf("made base\n");

 
 inn=new int[npts];

   
 for(i=0;i<threads;i++){
     printf("about to make tree %d %d\n",nparams,npts);
     kptr[i]=new kd_tree(nparams,npts,base,inn,mins,maxs);
     kptr[i]->check_tree(-1);
     printf("diag %d\n",kptr[i]->diagnostic);

 }
 delete [] inn;
 
 //after this time, the list of points sampled from parameter space
 //will be stored in the arrays kptr[i]->data[][]
 
 printf("threads %d\n",threads);
 for(i=0;i<threads;i++){
  kptr[i]->check_tree(-1);
  printf("tree %d diag %d\n",i,kptr[i]->diagnostic);
 }
 

 printf("done with tree\n");
 //now calculate chi squared for each of those points
 for(j=0;j<npts;j++){
  cc=call_likelihood(kptr[0]->data[j]);
  printf("called on j %d\n",j);
  
  kpa[j]=0.0;
  fpredicted[j]=0.0;
  sigma[j]=0.0;
  chisq[j]=cc;
  ddmin[j]=0.0;
  ddmax[j]=0.0;
  ddavg[j]=0.0;
  suboptime[j]=0;
  suboptpct[j]=0.0;
 
 }
 
 printf("assigned f, fpred, chisq\n");
 
 for(i=0;i<npts;i++)delete [] base[i];
 delete [] base;
 
 printf("done with initializer\n");
 }

void likelihood::resume(char *inname){

//if your run gets interrupted, call this routine instead of initialize

//inname will be the name of the last output the code wrote
//the routine will read that file and then you will be set to pick up
//where you left off

 int i,j,k,l,*inn,th,*tsubopt,nn[2],oldsubopt=0;
 double rn,tp,cc,tkp;
 char injunk[letters],word[letters];
 double *tsig,*tfp,*tchi,*tdmin,*tdmax,*tdavg,tr,number;
 double *tsubpct,*tkpa;
 double **base,dd[2];
 FILE *input;

 krigct=0;
 addct=0;
 krigtimewall=0.0;
 addtimewall=0.0;
 krigtimecpu=0.0;
 addtimecpu=0.0;

 suboptimal=0;
 suboptct=0;
 
 printf("about to read %s\n",inname);
 npts=0;
 
 //open the file and read through it to see how many points it contains
 input=fopen(inname,"r");
 while(fscanf(input,"%s %le ",injunk,&junk)==2){
  for(i=1;i<nparams;i++)fscanf(input,"%s %le ",word,&junk);
  while(compare_char(word,"kp")==0){
   //for this reason 'kp' should always be the last entry in the 
   //output file
   
    fscanf(input,"%s %le",word,&junk);
  }
  
  npts++;
 }
 fclose(input);
 
 startpts=npts;
 room=npts;
 
 printf("resuming with %d points already sampled from %s\n",\
 npts,inname);

 //These are temporary storage for things like chi squared, mu, and sigma.
 tsig=new double[npts];
 tfp=new double[npts];
 tchi=new double[npts];
 tdmin=new double[npts];
 tdmax=new double[npts];
 tsubopt=new int[npts];
 tsubpct=new double[npts];
 tdavg=new double[npts];
 tkpa=new double[npts];
		    
 fpredicted=new double[npts]; 
 kpa=new double[npts];
			
 sigma=new double[npts];

 chisq=new double[npts];
 
 base=new double*[npts]; 

 ddmin=new double[npts];
 ddmax=new double[npts];
 ddavg=new double[npts];
 suboptime=new int[npts];
 suboptpct=new double[npts];
			
 for(i=0;i<npts;i++){
  base[i]=new double[nparams];
 }
 
 inn=new int[npts];
 
 //now actually read the file
 input=fopen(inname,"r");
 for(i=0;fscanf(input,"%s %lf",injunk,&base[i][0])==2;i++){
  for(j=1;j<nparams;j++)fscanf(input,"%s %lf",word,&base[i][j]);
  
  while(compare_char(word,"kp")==0){
    fscanf(input,"%s %lf",word,&number);
    
    if(compare_char(word,"sig")==1)tsig[i]=number;
    else if(compare_char(word,"chisq")==1){tchi[i]=number;
      if(tchi[i]<0.01)tchi[i]=10.0*target;
    }
    else if(compare_char(word,"predicted")==1)tfp[i]=number;
    else if(compare_char(word,"ddmin")==1)tdmin[i]=number;
    else if(compare_char(word,"ddmax")==1)tdmax[i]=number;
    else if(compare_char(word,"ddavg")==1)tdavg[i]=number;
    else if(compare_char(word,"suboptimal")==1){tsubopt[i]=int(number);
      
      suboptimal=tsubopt[i];
      
      /*if(tsubopt[i]>oldsubopt)suboptimal++;
      oldsubopt=tsubopt[i];
      tsubopt[i]=suboptimal;*/
      
    }
    else if(compare_char(word,"suboptpct")==1)tsubpct[i]=number;
  }
  tkp=number;
  if(tkp>0.0)tsig[i]=tsig[i]/sqrt(tkp);
  else tsig[i]=tsig[i];
      //this is because the root_out.sav file stores sigma accounting
      //for the Kriging parameter; we want the array sigma[] to store
      //a generic sigma that can be rescaled for different Kriging
      //parameters
  
  tkpa[i]=tkp;
  
  //inn[i]=i;
  junk=dice->doub(); //just in case you started with the same seed
 }
 fclose(input);
 
 kriging_parameter=number;//kriging parameter will get set to the last value
 rkp=number;		//stored in your old run
			//there is code at the end of this routine to deal with the
			//possibility that the old run was lingering (kriging parameter = very small)
			//when it got interrupted

 
 suboptct=int(double(suboptimal)/tsubpct[npts-1]);
 
 //we will now build a kd tree in which we will store the evaluated points
 //we do this so that we have access to a fast nearest neighbor
 //search each time Kriging asks for the 15 nearest neighbors of
 //the candidate test point
 

 
 
 for(th=0;th<threads;th++){

   //inn will allows you to associate the order of chi squared, mu, etc. 
   //as it is read in
   //with the order of the points after they are arranged into the kdtree
   
   //(this is relevant for an older version of kd_tree() that rearranged
   //its inputs; I am just too lazy to rewrite the code, even though kd_tree
   //no longer behaves that way)
   
   for(j=0;j<npts;j++)inn[j]=j;
   
   kptr[th]=new kd_tree(nparams,npts,base,inn,mins,maxs);
   

   if(th==0){
   //because we only need one copy of these arrays, only do it for the zeroth 
   //thread
   
    ngood=0;
    for(i=0;i<npts;i++){
     fpredicted[i]=tfp[inn[i]];
     sigma[i]=tsig[inn[i]];
     chisq[i]=tchi[inn[i]];
     ddmax[i]=tdmax[inn[i]];
     ddmin[i]=tdmin[inn[i]];
     ddavg[i]=tdavg[inn[i]];
     suboptime[i]=tsubopt[inn[i]];
     suboptpct[i]=tsubpct[inn[i]];
     kpa[i]=tkpa[inn[i]];
     
     if(chisq[i]<=target+precision){ngood++;
       for(j=0;j<nparams;j++){
         if(kptr[th]->data[i][j]<CLmin[j])CLmin[j]=kptr[th]->data[i][j];
	 if(kptr[th]->data[i][j]>CLmax[j])CLmax[j]=kptr[th]->data[i][j];
       }
     
     }
    }
   }
   printf("wrote\n");
    

 }
 
 
 delete [] tfp;
 delete [] tchi;
 delete [] tsig;
 delete [] inn;
 for(i=0;i<npts;i++)delete [] base[i];
 delete [] base;
 delete [] tdmin;
 delete [] tdmax;
 delete [] tdavg;
 delete [] tsubopt;
 delete [] tsubpct;
 delete [] tkpa;
 
 
 
 //this is the code to set the kriging parameter 
 //in the case where the old run
 //was lingering when it got interrupted
 if(kriging_parameter<10.0){
   if(npts>1100)i=npts-1000;
   else i=npts/2;
   set_kp(i);
 }
 
 if(compare_char(inname,masteroutname)==1){
 nprinted=npts;
 }
 else{
  nprinted=0;
  write_pts();
 }
 printf("done resuming\n");
 
}


//USER MODIFIED FUNCTION
double likelihood::call_likelihood(double *v){
  
  //this is the function that calls the likelihood function
  //to evaluate chi squared
  
  //*v is the point in parameter space you have chosen to evaluate
  
  //as written, it calls the CAMB likelihood function for the CMB anisotropy 
  //spectrum
  
  int i,start;
  double params[14],chisquared,omm;
  double d1,d2,sncc;
  double cltt[3000],clte[3000],clee[3000],clbb[3000],el[3000];
  FILE *output;
  
  //code below this comment is a cartoon likelihood function
  
  
   d1=v[0]+5.0;
   d1=d1*1.9*pi/20.0;
  
    chisquared=1197.0+500.0*log(1.0+sin(d1)*sin(d1));
    for(i=1;i<nparams;i++)chisquared+=300.0*log(fabs(v[i])+1.0);
  
  
  //code below this comment interfaces with CAMB and the WMAP7 likelihood
  //function
  
 
 /*
  
  while((v[0]+v[1])/(v[2]*v[2])>1.0){
    v[0]=0.9*v[0];
    v[1]=0.9*v[1];
    v[2]=1.1*v[2];
    //in the event that total omega_matter>1
    //printf("had to futz\n");
  }
  
  for(i=0;i<6;i++)params[i]=v[i];
 
  for(i=0;i<3000;i++)el[i]=0;
  params[2]=100.0*params[2];
  params[5]=exp(params[5])*1.0e-10;
  

  camb_wrap_(params,el,cltt,clte,clee,clbb); //a function to call CAMB
  
  for(start=0;el[start]<1.0;start++);

  wmaplikeness_(&cltt[start],&clte[start],&clee[start],\
  &clbb[start],&chisquared); //a function to call the WMAP likelihood code

 //printf("done with likelihood\n");

  if(chisquared<0.01)chisquared=10.0*target; 
  			//in case the model was so pathological that the
			//likelihood code crashed and returned
			//chisquared=0  (this has been known to happen)
  

  */
  
  return chisquared;
  
}

void likelihood::add_pt(double *v, double *dd, double fin, double sin, \
double chitrue){
//once the code has chosen the best point for evaluation and called
//call_likelihood on it, this routine will add that point to the 
//kd tree of evaluated points for future use in the Gaussian process

//*v is the point in parameter space that you are adding
//*dd stores the distance between it and its nearest neighbors
//fin stores the value of mu predicted by the Gaussian process
//sin stores the value of sigma returned by the Gaussian process
//chitrue is the value of chi squared returned by call_likelihood

 double *fpbuff,*sbuff,*cbuff,cc;
 double *ddnb,*ddxb,*ddab,*subpctbuff,*kpbuff;
 int *subbuff;
 int i,j,k,l,th,*inn;
 
 //printf("in adding\n");

if(npts==room){
//you have evaluated so many points that you need to make more room in
//the chi squared, mu, etc. arrays

 kpbuff=new double[npts];
 fpbuff=new double[npts];
 sbuff=new double[npts];
 cbuff=new double[npts];
 ddnb=new double[npts];
 ddxb=new double[npts];
 ddab=new double[npts];
 subbuff=new int[npts];
 subpctbuff=new double[npts];
 
 #pragma omp parallel for
 for(i=0;i<npts;i++){
 
  kpbuff[i]=kpa[i];
  fpbuff[i]=fpredicted[i];
  sbuff[i]=sigma[i];
  cbuff[i]=chisq[i];
  ddnb[i]=ddmin[i];
  ddxb[i]=ddmax[i];
  ddab[i]=ddavg[i];
  subbuff[i]=suboptime[i];
  subpctbuff[i]=suboptpct[i];
 }

 delete [] kpa;
 delete [] fpredicted;
 delete [] sigma;
 delete [] chisq;
 delete [] ddmin;
 delete [] ddmax;
 delete [] ddavg;
 delete [] suboptime;
 delete [] suboptpct;
 
 #pragma omp parallel for
 for(th=0;th<threads;th++){
  kptr[th]->add(v);
  //the kdtree code has its own infrastucture for dealing with
  //the size of the tree and when you need to make more room
 }

 npts=kptr[0]->pts;

 room+=roomstep;

 kpa=new double[room];
 fpredicted=new double[room];
 sigma=new double[room];
 chisq=new double[room];
 ddmin=new double[room];
 ddmax=new double[room];
 ddavg=new double[room];
 suboptime=new int[room];
 suboptpct=new double[room];

 #pragma omp parallel for
 for(i=0;i<npts-1;i++){
  
  kpa[i]=kpbuff[i];
  fpredicted[i]=fpbuff[i];
  sigma[i]=sbuff[i];
  chisq[i]=cbuff[i];
  ddmin[i]=ddnb[i];
  ddmax[i]=ddxb[i];
  ddavg[i]=ddab[i];
  suboptime[i]=subbuff[i];
  suboptpct[i]=subpctbuff[i];
 }
 
 kpa[npts-1]=kriging_parameter;
 fpredicted[npts-1]=fin;
 sigma[npts-1]=sin;
 
 suboptime[npts-1]=suboptimal;
 suboptpct[npts-1]=double(suboptimal)/double(suboptct);
 chisq[npts-1]=chitrue;
 
 if(chisq[npts-1]<=target+precision){
   ngood++;
   for(i=0;i<nparams;i++){
     if(v[i]<CLmin[i])CLmin[i]=v[i];
     if(v[i]>CLmax[i])CLmax[i]=v[i];
   }
 }
 
 ddmin[npts-1]=dd[0];
 ddmax[npts-1]=dd[0];
 ddavg[npts-1]=0.0;
 for(i=0;i<kk;i++){
  if(dd[i]<ddmin[npts-1])ddmin[npts-1]=dd[i];
  if(dd[i]>ddmax[npts-1])ddmax[npts-1]=dd[i];
  ddavg[npts-1]+=dd[i];
 }
 ddavg[npts-1]=ddavg[npts-1]/double(kk);
 
// printf("assigned new f\n");

 delete [] kpbuff;
 delete [] fpbuff;
 delete [] sbuff;
 delete [] cbuff;
 delete [] ddnb;
 delete [] ddxb;
 delete [] ddab;
 delete [] subbuff;
 delete [] subpctbuff;
 }//if pts==room
 else{
 
 //printf("plenty of room\n");
 
 //if you already have room in the relevant arrays
#pragma omp parallel for
   for(th=0;th<threads;th++){
    kptr[th]->add(v);

   }
 //printf("k added\n");
 
   npts=kptr[0]->pts;
 
   kpa[npts-1]=kriging_parameter;
   fpredicted[npts-1]=fin;
   sigma[npts-1]=sin;
   chisq[npts-1]=chitrue;
   suboptime[npts-1]=suboptimal;
   suboptpct[npts-1]=double(suboptimal)/double(suboptct);
 
 if(chisq[npts-1]<=target+precision){
   
   ngood++;
   
   for(i=0;i<nparams;i++){
     if(v[i]<CLmin[i])CLmin[i]=v[i];
     if(v[i]>CLmax[i])CLmax[i]=v[i];
   } 
 }
 
  
   ddmin[npts-1]=dd[0];
   ddmax[npts-1]=dd[0];
   ddavg[npts-1]=0.0;
   for(i=0;i<kk;i++){
    if(dd[i]<ddmin[npts-1])ddmin[npts-1]=dd[i];
    if(dd[i]>ddmax[npts-1])ddmax[npts-1]=dd[i];
    ddavg[npts-1]+=dd[i];
   }
   ddavg[npts-1]=ddavg[npts-1]/double(kk);

 
 }
 
 //printf("added %d lm %d\n",npts,lingermax);
 
 if(npts%(writevery)==0){
 //printf("\nwriting %d\n\n",npts);
   write_pts();
   if(suboptimal-lastsubop<10){
      rkp=10.0*rkp;
    }
   else if(suboptimal-lastsubop>9*writevery/10){
      rkp=0.5*rkp;
    }
   if(kriging_parameter>kpmin)kriging_parameter=rkp;
   lastsubop=suboptimal;
 }
 //printf("assessed writing\n");
 
}


void likelihood::sample_pts(int delswit){
//generates a random set of candidate points
//uses a Gaussian process to find which is the best for actual evaluation with
//call_likelihood() 

//adds the best scoring one to the sample of known data

//delswit>0 means that the routine will go ahead and sample points
//delswit<0 means that the routine will delete its allocated pointers
//and exit

 static int samplinit=0;
 int i,j,k,l,maxdex=0,lct;
 double *bestpt,mu,sig,strad,**vdummy;
 double beforewall,afterwall,chibar;
 double beforecpu,aftercpu,startchi;
 static int called=0;
 
 static int **neigh,*calledthread;
 static double **sample,**bestpts,*mufound,*sfound;
 static double **dd,***neighpts,**neighf,*stradmax;
 static double **gg,**ggin,*ggq,ldmufactor;
 
 static double **keptd,*bestkeptd,*closest,*dmu;
 double chitrue,dchi,dx,ldmu;
 
 int th,ddint;
 double stradfinal,sfinal,mufinal;

 FILE *output;
 
 vdummy=new double*[threads];
 for(i=0;i<threads;i++)vdummy[i]=new double[nparams];
 
 if(called==0){
   calledthread=new int[threads];
   gg=new double*[kk];
   ggin=new double*[kk];
   for(i=0;i<kk;i++){
     gg[i]=new double[kk];
     ggin[i]=new double[kk];
   }
   ggq=new double[kk];
   
   dmu=new double[nparams];
   closest=new double[threads];
   keptd=new double*[threads];
   bestkeptd=new double[kk];
   neigh=new int*[threads];
   dd=new double*[threads];
   neighpts=new double**[threads];
   neighf=new double*[threads];
   mufound=new double[threads];
   sfound=new double[threads];
   stradmax=new double[threads];
   sample=new double*[threads];
   bestpts=new double*[threads];

   for(th=0;th<threads;th++){
     keptd[th]=new double[kk];  
     neigh[th]=new int[kk];
     dd[th]=new double[kk];
     neighpts[th]=new double*[kk];
     for(i=0;i<kk;i++)neighpts[th][i]=new double[nparams];
     neighf[th]=new double[kk];
 
     bestpts[th]=new double[nparams];
     sample[th]=new double[nparams];
   }
  called=1;
 }//if called==0

 if(delswit>0){
 
 for(th=0;th<threads;th++){
   stradmax[th]=-1.0e20;
   closest[th]=1.0e20;
   calledthread[th]=0;
 }
 
 beforewall=double(time(NULL));
 beforecpu=double(clock());

 //printf("sampling again\n");

 #pragma omp parallel for private(j,k,l,strad,mu,sig,th,ddint)
 for(i=0;i<nsamples;i++){
 th=omp_get_thread_num();

  #pragma omp critical (flip_a_coin)
  for(j=0;j<nparams;j++){
   sample[th][j]=(maxs[j]-mins[j])*dice->doub()+mins[j];   
  }
  //the code above generates the random sample

  kptr[th]->nn_srch(sample[th],kk,neigh[th],dd[th]); 
                         //find the kk nearest neighbors
  			//the neighbors are stored in neigh[th] 
			//as a list of nodes on
			//the kdtree
  
  for(j=0;j<kk;j++){
   for(l=0;l<nparams;l++){
     neighpts[th][j][l]=kptr[th]->data[neigh[th][j]][l];  
     //here, there neighbors are stored as points in parameter space
   }
   neighf[th][j]=chisq[neigh[th][j]];
   //this stores the values of chi squared associated with the neighbors
  }

  //do the Kriging/Gaussian Process
  predict(neighpts[th],neighf[th],sample[th],dd[th],kk,nparams,&mu,&sig,1);

  if(fabs(mu-target)<closest[th])closest[th]=fabs(mu-target);
  //keeping track of the closest candidate point considered

  strad=1.96*sig*sqrt(kriging_parameter)-fabs((mu-target));
  //the Kriging parameter appears here because the subroutine predict()
  //yields the value of sigma if the kriging parameter were equal to unity
  
  if(!(sig>0.0)){
    //error message
    output=fopen("gp_error.sav","a");
    fprintf(output,"strad is %e mu %e sig %e npts %d\n",strad,mu,sig,npts);
    
    fprintf(output,"\n found nn\n");
   for(j=0;j<kk;j++){
    fprintf(output,"%d ",neigh[th][j]);
    for(l=0;l<nparams;l++)\
    fprintf(output,"(%.2e %.2e) ",\
    neighpts[th][j][l],kptr[th]->data[neigh[th][j]][l]);
    fprintf(output,"\n");
   }
   kptr[th]->check_tree(-1);
   fprintf(output,"tree check is %d\n",kptr[th]->diagnostic);
  
   fclose(output);

  }
  
  if(strad>stradmax[th] || calledthread[th]==0){
                         //each omp thread stores its own best point
   maxdex=i;		//they will compare notes after the calculation
   stradmax[th]=strad;  //is done
   mufound[th]=mu;
   sfound[th]=sig;
   calledthread[th]=1;
   for(l=0;l<nparams;l++)bestpts[th][l]=sample[th][l];
   for(l=0;l<kk;l++){
     keptd[th][l]=0.0;
     for(j=0;j<nparams;j++){
       keptd[th][l]+=power((sample[th][j]-neighpts[th][l][j])/(maxs[j]-mins[j]),2);
     }
     keptd[th][l]=sqrt(keptd[th][l]);
   } 
  }
  
 }


 //below is where the omp threads compare to see which one found the
 //absolute best straddle point
 bestpt=bestpts[0];
 mufinal=mufound[0];
 sfinal=sfound[0];
 stradfinal=stradmax[0];
 
 for(l=0;l<kk;l++){
  bestkeptd[l]=keptd[0][l];
 }
 
 
 for(th=1;th<threads;th++){
  if(stradmax[th]>stradfinal){
   stradfinal=stradmax[th];
   mufinal=mufound[th];
   sfinal=sfound[th];
   bestpt=bestpts[th];
  }
  for(l=0;l<kk;l++){
    bestkeptd[l]=keptd[th][l];
  }
 }
 
 //did a point get chosen based on sigma rather than
 //proximity to the target value?
 strad=closest[0];
 for(th=1;th<threads;th++){
  if(closest[th]<strad)strad=closest[th];
 }
 if(fabs(mufinal-target)>strad)suboptimal++; 
 
 afterwall=double(time(NULL));
 aftercpu=double(clock());
 if(samplinit>0){
   krigtimewall+=(afterwall-beforewall);
   krigtimecpu+=(aftercpu-beforecpu);
   krigct++;
 }

 beforewall=double(time(NULL));
 beforecpu=double(clock());
 chitrue=call_likelihood(bestpt);
 
 suboptct++; //how many points were selected while not lingering
 add_pt(bestpt,bestkeptd,mufinal,sfinal,chitrue);
 
// printf("out of adding\n");
 
 afterwall=double(time(NULL));
 aftercpu=double(clock());
 
 if(samplinit>0){
   addct++;
   addtimewall+=(afterwall-beforewall);
   addtimecpu+=(aftercpu-beforecpu);
 }
 else samplinit++;


 //below is the code to handle lingering around highly likely points
 
 if(lingerswitch==1 && fabs(chisq[npts-1]-target)<0.1*target \
 && chisq[npts-1]!=target){
    //printf("starting to linger %e %d %e\n",chisq[npts-1],lingermax,precision);
   
    kriging_parameter=kpmin;
    //this is a warning to output routines that these points were sampled
    //under lingering
       
   ldmufactor=0.001;
   
   startchi=chisq[npts-1];
   for(lct=0;lct<lingermax && fabs(startchi-chimin)>=0.4*precision\
   && ldmufactor>1.0e-7;lct++){
 
      for(j=0;j<nparams;j++)bestpts[0][j]=kptr[0]->data[npts-1][j];
     startchi=chisq[npts-1];
     
     kptr[0]->nn_srch(bestpts[0],kk,neigh[0],dd[0]); 
    
    chibar=0.0;                   
    for(j=0;j<kk;j++){
     for(l=0;l<nparams;l++){
       neighpts[0][j][l]=kptr[0]->data[neigh[0][j]][l];  
       //here, there neighbors are stored as points in parameter space
     }
     neighf[0][j]=chisq[neigh[0][j]];
     chibar+=neighf[0][j];
     //this stores the values of chi squared associated with the neighbors
    }
    chibar=chibar/double(kk);

   

    for(i=0;i<kk;i++){
      for(j=i;j<kk;j++){
        gg[i][j]=covariogram(neighpts[0][i],neighpts[0][j],nparams);
        if(i!=j)gg[j][i]=gg[i][j];
        else if(i==j)gg[i][j]=1.0001*gg[i][j];
      }
    }
  
    invert_lapack(gg,ggin,kk,1);
    for(i=0;i<kk;i++)ggq[i]=covariogram(neighpts[0][i],bestpts[0],nparams);
    
    //calculate the direction of the gradient of chi squared
    //using a Gaussian process
    for(k=0;k<nparams;k++){
      dmu[k]=0.0;
      for(i=0;i<kk;i++){
        for(j=0;j<kk;j++){
	 dmu[k]+=-1.0*(bestpts[0][k]-neighpts[0][j][k])\
	 *ggq[j]*ggin[j][i]*(neighf[0][i]-chibar)/(maxs[k]-mins[k]); 
	}
      }
      
    }
    
    chitrue=3.0*target;
    
     ldmu=0.0;
     for(j=0;j<nparams;j++)ldmu+=dmu[j]*dmu[j];
     ldmu=sqrt(ldmu);
    
    
    dchi=chimin-startchi;
   
    while(chitrue>2.0*target && ldmufactor>1.0e-7){
      //printf("chitrue %e ldmuf %e\n",chitrue,ldmufactor);
      dx=ldmufactor*dchi/ldmu;
    
      for(j=0;j<nparams;j++){
         sample[0][j]=bestpts[0][j]+dx*dmu[j];
      }
     
     j=1;
     for(k=0;k<nparams;k++){
      if(sample[0][k]<mins[k] || sample[0][k]>maxs[k]){j=0;
         //make sure the sample point is within the allowed bounds
	 //on parameter space
      }
     } 
     if(j==1){ 
      chitrue=call_likelihood(sample[0]);
      spentlingering++;
      
      for(k=0;k<kk;k++)dd[0][k]=0.0;//so that points found with
      				//gradient descent are easily identified
				//in output file
    
    add_pt(sample[0],dd[0],target,0.0,chitrue);
    
       if(chitrue>=2.0*target)ldmufactor=ldmufactor/2.0;
     
     }
     else{ ldmufactor=ldmufactor/2.0;}//this is if the sample point
     					//was outside the parameter
					//space bounds.
    }

  
  }
  //printf("done lingering %e %d %e\n\n",chisq[npts-1],lct,ldmufactor);
 

  kriging_parameter=rkp;
 
 
 }
 
 }//if delswit>0
 else if(called>0){
 
 delete [] calledthread;
 delete [] closest;
 delete [] mufound;
 delete [] sfound;
 delete [] stradmax;
 
 
 for(th=0;th<threads;th++){
   delete [] sample[th];
   delete [] bestpts[th];
   delete [] neigh[th];
   delete [] dd[th];
   for(i=0;i<kk;i++)delete [] neighpts[th][i];
   delete [] neighpts[th];
   delete [] neighf[th];
   
   delete [] keptd[th];
 
 }
 delete [] sample;
 delete [] bestpts;
 delete [] neigh;
 delete [] dd;
 delete [] neighpts;
 delete [] neighf;
 delete [] keptd;
 delete [] bestkeptd;
 delete [] dmu;
 for(i=0;i<kk;i++){
   delete [] gg[i];
   delete [] ggin[i];
 }
 delete [] gg;
 delete [] ggin;
 delete [] ggq;
 
   called=0;
 }

 for(i=0;i<threads;i++)delete [] vdummy[i];
 delete [] vdummy;

//ddfile fclose(output);
// printf("done sampling\n");
}

void likelihood::write_pts(){

//this routine will write the evaluated points along with
//*sigma, chi squared, *fpredicted, and the difference between
//chi squared and *fpredicted into the file *name

 FILE *output,*timefile,*goodfile;
 int i,j,th;
 int tot,trapped,good,tried,wayoff,dontcount;
 double trappedpct;
 
 
 for(i=0;i<threads;i++){
  //check to make the kdtrees are still properly constructed
  kptr[i]->check_tree(-1);
  //printf("tree %d\n",kptr[i]->diagnostic);
 }
 
 //printf("checked all trees\n");
 
 tot=0;
 trapped=0;

 
 
 good=0;
 tried=0;
 wayoff=0;
 dontcount=0;


  output=fopen(masteroutname,"a");

 tot=0;
 trapped=0;
 
 //goodfile=fopen("goodpts.sav","w");
 
 for(i=0;i<npts;i++){//printf("i %d np %d\n",i,nprinted);
  
  //this code determines what percentage of points (ignoring lingering)
  //were actually trapped within their 1-sigma kriging bounds 
  //note: this trapped percentage assumes that all points were sampled
  //with the current Kriging parameter
  //it is another way to judge whether or not our choice of Kriging parameter
  //was appropriate
   
     if(sigma[i]>0.0 && kpa[i]>kpmin){
      tot++;
      if(fabs(fpredicted[i]-chisq[i])\
      <=sqrt(kriging_parameter)*sigma[i])trapped++;
    }
   // printf("checked trapped and tot\n");
 
  if(tot>0){
   trappedpct=double(trapped)/double(tot);
  }
  else trappedpct=0.0;
  
  if(chisq[i]<target+precision){good++;

  }
  
  //printf("checked good\n");
  
  //below, ``tried'' keeps track of points that were chosen within 10% of target
  //``wayoff'' keeps track of points that were chosen that were more than 90%
  //different from target
  //This is another way to evaluate our choice of Kriging parameter
  
  if(fabs(fpredicted[i]-target)/target<0.1 && sigma[i]>0.0 \
  && kpa[i]>1.1*kpmin)\
  tried++;
  else if(fabs(fpredicted[i]-target)/target>0.9 && sigma[i]>0.0 && \
  kpa[i]>1.1*kpmin)wayoff++;
  else if(sigma[i]<=0.0 || kpa[i]<=1.1*kpmin)dontcount++;
 
  if(i>=nprinted){//no need to print points that have already been printed
  
  for(j=0;j<nparams;j++){
   fprintf(output,"%s %e ",pnames[j],kptr[0]->data[i][j]);
  }
  fprintf(output,"chisq %e ",chisq[i]);
  fprintf(output,"predicted %e sig %e ",\
  fpredicted[i],sqrt(kpa[i])*sigma[i]);
  fprintf(output,"diffpct %e ",fabs((chisq[i]-fpredicted[i])/chisq[i]));
  fprintf(output,"ddmin %e ddmax %e ddavg %e ",ddmin[i],ddmax[i],ddavg[i]);
  fprintf(output,\
  "goodpct %e triedpct %e wayoff %e suboptimal %d suboptpct %e trappedpct %e ",\
  double(good)/double(i+1),double(tried)/double(i+2-dontcount),\
  double(wayoff)/double(i+2-dontcount),\
  suboptime[i],suboptpct[i],trappedpct);
 
  fprintf(output,"kp %e\n",kpa[i]);
  }//if(i>=nprinted)
  
 }
 fclose(output);
 //fclose(goodfile);

 
 timefile=fopen("timingfile.sav","a");
 fprintf(timefile,"%s %d ling %d gd %d ",masteroutname\
 ,npts,spentlingering,ngood);
  fprintf(timefile,"avgkrigtimewall %e avgaddtimewall %e ns %d kk %d ",\
  krigtimewall/double(krigct),addtimewall/double(addct),nsamples,kk);
     fprintf(timefile,"avgkrigtimecpu %e avgaddtimecpu %e ",\
     krigtimecpu/double(krigct),addtimecpu/double(addct));
 fprintf(timefile,"suboptpct %e ct %d kp %e ",suboptpct[npts-1],\
 suboptct,kriging_parameter);
 for(th=0;th<threads;th++)fprintf(timefile,"kd%d %d ",th,kptr[th]->diagnostic);
 //for(th=0;th<nparams;th++)printf("%s %e %e ",pnames[th],CLmin[th],CLmax[th]);
 fprintf(timefile,"target %e\n",target);
 fclose(timefile);
 
 
 
  //reset variables related to timing performance
   krigct=0;
   addct=0;
   addtimecpu=0.0;
   addtimewall=0.0;
   krigtimewall=0.0;
   krigtimecpu=0.0;
   
   nprinted=npts;


}

double likelihood::covariogram(double *v1, double *v2, int coords){

 int i;
 double ans,d;
 
 d=0.0;
 for(i=0;i<coords;i++){
  d+=power((v1[i]-v2[i])/(maxs[i]-mins[i]),2);
 }
 ans=exp(-0.5*d);
 return ans;
 
}



void likelihood::predict(double **old, double *ffn, double *q, double *dd, \
int pts, int coords, double *mu, double *sig, int delswit){

//this subroutine actually does the Kriging/Gaussian Process

//**old stores the coordinates of the kk nearest neighbors in parameter space

//*ffn is the chisquared values associated with the neighbors

//*q is the test point being considered

//*dd stores the distances to the kk nearest neighbors

//pts is really just kk (the number of points in **old and *ffn)

//coords is the dimensionality of parameter space (i.e., nparams)

//*mu is where the predicted value of chi squared at *q gets stored

//*sig is the uncertainty on *mu

//delswit is an integer; delswit>0 means this routine will do Kriging
//delswit<0 means that it will delete its allocated pointers and exit

//delswit==2 causes the routine to print updates about where it is in the
//process (this is probably not very useful)

  double fbar,err,junk,d;
  int i,j,k,l;
  double static **gg,**ggin,*ggq;
  static int called=0;
  
  if(called==0){
    gg=new double*[pts];
  
    ggin=new double*[pts];
    for(i=0;i<pts;i++){
     gg[i]=new double[pts];
     ggin[i]=new double[pts];
  
   }
   ggq=new double[pts];
   called=1;
  }
  
  if(delswit<0 && called>0){
    delete [] ggq;
    for(i=0;i<pts;i++){
      delete [] gg[i];
      delete [] ggin[i];
    }
    
    delete [] gg;
    delete [] ggin;
    called=0;
  }
  else{
  
  for(i=0;i<pts;i++){
   for(j=i;j<pts;j++){
     gg[i][j]=covariogram(old[i],old[j],coords);
     if(i!=j)gg[j][i]=gg[i][j];
     else if(i==j)gg[i][j]=gg[i][j]*1.001;
   }
  }
  
  if(delswit==2){printf("made gg\n\n");
  
  }
  invert_lapack(gg,ggin,pts,delswit);
  
  if(delswit==2)printf("inverted gg\n");
  
  //the comments below are code to check that the matrix inversion worked;
  //you can generally trust lapack
  
  //err=check_inversion(gg,ggin,pts);
  //if(err>maxerr)maxerr=err;

  for(i=0;i<pts;i++)ggq[i]=covariogram(old[i],q,coords);

  fbar=0.0;
  for(i=0;i<pts;i++)fbar+=ffn[i];
  fbar=fbar/double(pts);
  
  *mu=fbar;
  
  for(i=0;i<pts;i++){
   for(j=0;j<pts;j++){
    *mu+=ggq[i]*ggin[i][j]*(ffn[j]-fbar);
   }
  }
    
  *sig=0.0;
  for(i=0;i<pts;i++){
   for(j=0;j<pts;j++){
     *sig+=ggq[i]*ggq[j]*ggin[i][j];

   }
  }
  
  *sig=covariogram(q,q,coords)-*sig;
      d=*sig;
     *sig=sqrt(fabs(*sig));

  }

}


double likelihood::test_kp(int pts, char *name){

//this is a subroutine to test how good a choice your Kriging parameter
//actually is.  It will generate 'pts' random points, run them through
//Kriging, and tell you what percentage of them actually fall within
//the 1-sigma range of chi squared.  The results are stored in the
//file specified by *name


   double err,cc;
   double **kx,*ky,*kmu,*ksig;
   double ***neighpts,**dd,**neighf;
   int i,j,k,l,th,**neigh;
   int trapped;
   FILE *output;


   trapped=0;
  

  neigh=new int*[threads];
  dd=new double*[pts];
  neighpts=new double**[threads];
  neighf=new double*[threads];

  for(th=0;th<threads;th++){
   neigh[th]=new int[kk];
   neighpts[th]=new double*[kk];
   for(i=0;i<kk;i++)neighpts[th][i]=new double[nparams];
   neighf[th]=new double[kk];
  }
  
  kx=new double*[pts];
  for(i=0;i<pts;i++){
     kx[i]=new double[nparams];
     dd[i]=new double[kk];
  }
  ky=new double[pts];
  kmu=new double[pts];
  ksig=new double[pts];

#pragma omp parallel for private(i,j,k,l,th)
  for(i=0;i<pts;i++){
    th=omp_get_thread_num();
    
#pragma omp critical (flip_a_coin_kp)
    for(j=0;j<nparams;j++){
     kx[i][j]=(maxs[j]-mins[j])*dice->doub()+mins[j];
    }
  

   kptr[th]->nn_srch(kx[i],kk,neigh[th],dd[i]);
   
    
    for(j=0;j<kk;j++){
      for(l=0;l<nparams;l++){
        neighpts[th][j][l]=kptr[th]->data[neigh[th][j]][l];  
      }
      neighf[th][j]=chisq[neigh[th][j]];
    }
    predict(neighpts[th],neighf[th],kx[i],dd[i],kk,nparams,&ky[i],&ksig[i],1);
  
  }
  
  printf("ready to call like\n");
  //cannot parallelize this part because of how CAMB works
  for(i=0;i<pts;i++){
    kmu[i]=call_likelihood(kx[i]);

    if(fabs(kmu[i]-ky[i])<=sqrt(rkp)*ksig[i]){
     trapped++;
    }
    
    
    add_pt(kx[i],dd[i],ky[i],ksig[i],kmu[i]);
    //add the point to the tree so you still learn something from having
    //called the likelihood function

  }

 output=fopen(name,"a");
  fprintf(output,\
  "%s kptest pts %d trapped %d pct %e npts %d kp %e subopt %d\n",\
  masteroutname,pts,trapped,double(trapped)/double(pts),npts,rkp,suboptimal);
 fclose(output);


  for(i=0;i<pts;i++){
   delete [] kx[i];
   delete [] dd[i];
  }
  
  for(th=0;th<threads;th++){
   for(i=0;i<kk;i++)delete [] neighpts[th][i];
   delete [] neighpts[th];
   delete [] neigh[th];
   delete [] neighf[th];
  
  }
  
  delete [] dd;
  delete [] neighf;
  delete [] neighpts;
  delete [] neigh;
  delete [] kx;
  delete [] ky;
  delete [] kmu;
  delete [] ksig;
  
  return double(trapped)/double(pts);

}

void likelihood::set_kp(int ignore){
   
//This routine will set the Kriging parameter heuristically.
//It looks through the points already sampled (ignoring
//the first set of points, the length of which is specified
//by the integer 'ignore') and sets the Kriging parameter
//to that value such that 68% of the points sampled
//would have been in the 1-sigma interval predicted by the
//Gaussian process
   
   double *rat;
   int *sind,i,ct;
 
   
   rat=new double[npts];
   sind=new int[npts];
   
   ct=0;
   for(i=0;i<npts;i++){
    if(sigma[i]>0.0 && i>ignore){
     
     rat[ct]=power((chisq[i]-fpredicted[i])/sigma[i],2);
     sind[ct]=ct;
     
     ct++;
     
    }
   }
   
   sort(rat,sind,ct);
   kriging_parameter=rat[ct*68/100];
   rkp=kriging_parameter;
   
   
   delete [] rat;
   delete [] sind;
   
}



